"""6.009 Lab 5 -- Boolean satisfiability solving"""

import sys
sys.setrecursionlimit(10000)
# NO ADDITIONAL IMPORTS


def satisfying_assignment(formula):
    """Find a satisfying assignment for a given CNF formula.
    Returns that assignment if one exists, or None otherwise.

    >>> satisfying_assignment([])
    {}
    >>> sa = satisfying_assignment([[('a', True), ('b', False), ('c', True)]])
    >>> ('a' in sa and sa['a']) or ('b' in sa and not sa['b']) or ('c' in sa and sa['c'])
    True
    >>> satisfying_assignment([[('a', True)], [('a', False)]]) is None
    True
    """
    return None

def simplify_formula(formula, assignments):
    '''
      Input: a boolean formula in the CNF format described above.
            a set of assignments to boolean variables represented as a dictionary
            from variables to boolean values.
      Output: a pair (Formula, Changed), where Formula is
      the new simplified formula, and Changed is a boolean
      that determines whether or not the simplification added new
      assignments. If the assignment causes the formula to
      evaluate to False, you should return (None, False).
      Effects: the operation potentially adds new assignments to
      assignments. However, the operation should NOT modify
      the input formula when creating the output (although it is ok
        for the output formula to share unchanged clauses with the input formula).

      Note that when the simplification creates new assignments,
      those assignments may themselves enable further simplification.
      You should make sure all those newly enabled simplifications
      are performed as well.

      It is advised that you write your own tests for this function.
    '''
    return None

def managers_for_actors(K, film_db):
    '''
    Input:
       K , number of managers available.
       film_db, a list of [actor, actor, film] triples describing that two
       actors worked together on a film.
    Output:
        A dictionary representing an assignment of actors to managers, where
        actors are identified by their numerical id in film_db and
        managers are identified by a number from 0 to K-1.
        The assignment must satisfy the constraint that
        if two actors acted together in a film, they should not have the
        same manager.
        If no such assignment is possible, the function returns None.

    You can write this function in terms of three methods:
        make_vars_for_actors: for each actor in the db, you want an indicator
        variable for every possible manager indicating whether that manager
        is the manager for that actor.

        make_one_manager_constraints: This function should create constraints that
        ensure that each actor has one and only one manager.

        make_different_constraint: This function should create constraints
        that ensure that each actor has a different manager from other actors
        in the same movie.

    '''
    return None

def check_solution(sol, K, film_db):
    '''
    Input:
        K, number of managers
        flim_db, a list of [actor, actor, film] triples describing that two
        actors worked together on a film.
        sol, an assignment of actors to managers.
    Output:
        The function returns True if sol satisfies the constraint that
        if two actors acted together in a film, they should not have the
        same manager and every manager has an ID less than K.
        It returns False otherwise.
    '''
    return False
